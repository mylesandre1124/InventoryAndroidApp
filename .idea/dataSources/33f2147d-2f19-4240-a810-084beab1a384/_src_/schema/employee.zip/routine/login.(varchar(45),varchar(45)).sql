CREATE PROCEDURE login(IN usernameToCheck VARCHAR(45), IN passwordToCheck VARCHAR(45))
  BEGIN
	declare token varchar(250);
    declare empID int;

	SELECT employee.empId into empID
	FROM employee.employee
	WHERE username = usernameToCheck and password = passwordToCheck
	limit 1;
    
    if(empID is not null)
    then
		if((select authorizationToken from employee.authorize where authorize.empId = empID) is null)
			then
				insert into employee.authorize 
				set authorize.empId = empID, authorize.authorizationToken = concat(REPLACE(UUID(),'-',''), REPLACE(UUID(),'-',''), REPLACE(UUID(),'-',''));
				select authorizationToken 
				from employee.authorize
				where authorize.empId = empID;
		elseif ((select authorizationToken from employee.authorize where authorize.empId = empID) is not null)
			then 
				update employee.authorize 
				set authorize.authorizationToken = concat(REPLACE(UUID(),'-',''), REPLACE(UUID(),'-',''), REPLACE(UUID(),'-',''))
				where authorize.empId = empID;
				select authorizationToken 
				from employee.authorize
				where authorize.empId = empID;
		end if;
	end if;
    
END;
