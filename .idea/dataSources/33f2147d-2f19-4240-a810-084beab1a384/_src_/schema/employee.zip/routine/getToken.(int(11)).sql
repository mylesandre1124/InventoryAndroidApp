CREATE PROCEDURE getToken(IN empID INT)
  BEGIN
	select authorize.authorizationToken
	from employee.authorize
	where authorize.empId = empID;
END;
